namespace CuteAnimal
{
    public enum Mood
    {
        Happy,
        Grumpy,
        IgnoringYou,
        HyperActive
    }
}
