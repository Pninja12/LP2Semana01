namespace CuteAnimal
{
    public enum Feed
    {
        Starving,
        Hungry,
        Satisfied,
        Full,
        AboutToExplode
    }
}
